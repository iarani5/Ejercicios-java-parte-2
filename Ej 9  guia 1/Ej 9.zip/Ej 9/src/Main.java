import javax.swing.JOptionPane;

public class Main {

	public static void main(String[] args) {
		int cantidad_total = Integer.parseInt(JOptionPane.showInputDialog("\nCantidad de superficie total(m): "));
		ObraEdificio nueva_obra = new ObraEdificio(cantidad_total);
		boolean finalizado;
		
		do{
			int cantidad_actual = Integer.parseInt(JOptionPane.showInputDialog("\nCantidad de superficie a cimientar(m): "));
			nueva_obra.cimentado(cantidad_actual);
			int resto=nueva_obra.restaPorCimentar();
			System.out.print("\nAun restan por cimentar: "+resto+" m");
			finalizado=nueva_obra.terminado();
		}while(finalizado!=true);
		System.out.print("\nSuperficie cimentada con exito!");
	}

}
