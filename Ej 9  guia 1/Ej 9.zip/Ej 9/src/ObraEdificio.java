
public class ObraEdificio {
	public int superficie_total;
	public int superficie_actual; //m2 sin decimales
	
	public ObraEdificio (int x){
		this.superficie_total=x;
	}
	
	public void cimentado (int num){
		if(!(num+superficie_actual>superficie_total)){
			superficie_actual+=num;
		}
		else{
			System.out.print("\nError. No es posible cimentar una superficie mayor a la total");
		}
	}	
	
	public int restaPorCimentar(){
		return superficie_total-superficie_actual;
	}
	

	public boolean terminado(){
		return superficie_total==superficie_actual;
	}
}
